import cv2
a=cv2.VideoCapture(1)
while(True):
	ret,frame=a.read()
	cv2.imshow("Streaming",frame)
	if cv2.waitKey(10) & 0xff ==ord("q"):
		break
a.release()
